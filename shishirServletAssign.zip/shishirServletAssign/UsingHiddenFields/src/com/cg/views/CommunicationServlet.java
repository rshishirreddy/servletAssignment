package com.cg.views;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/CommunicationServlet")
public class CommunicationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public CommunicationServlet() {
        super();
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		String firstName=request.getParameter("firstName");
		String lastName=request.getParameter("lastName");
		String city=request.getParameter("city");
		String state=request.getParameter("state");
		out.println("<html>");
		out.println("<head>");
		out.println("</head>");
		out.println("<body>");
		
		out.println("<table>");
		out.println("<tr>");
		out.println("<td>FirstName</td>");
		out.println("<td>"+firstName+"</td>");
		out.println("</tr>");
		
		out.println("<tr>");
		out.println("<td>LastName</td>");
		out.println("<td>"+lastName+"</td>");
		out.println("</tr>");
		
		out.println("<tr>");
		out.println("<td>City</td>");
		out.println("<td>"+city+"</td>");
		out.println("</tr>");
		
		out.println("<tr>");
		out.println("<td>State</td>");
		out.println("<td>"+state+"</td>");
		out.println("</tr>");		
		out.println("</table>");
		
		
		out.println("<form name='Addressform' action='FinalServlet' method='post'>");
		out.println("<table>");
		

		out.println("<tr>");
		out.println("<td><input type='hidden' name='firstName' value='"+firstName+"'></td>");
		out.println("</tr>");
		
		out.println("<tr>");
		out.println("<td><input type='hidden' name=lastName value="+lastName+"></td>");
		out.println("</tr>");
		
		out.println("<tr>");
		out.println("<td><input type='hidden' name='city' value='"+city+"'></td>");
		out.println("</tr>");
		
		out.println("<tr>");
		out.println("<td><input type='hidden' name='state' value='"+state+"'></td>");
		out.println("</tr>");
		
		out.println("<tr>");
		out.println("<td>MobileNo</td>");
		out.println("<td><input type='text' name='mobileNo'></td>");
		out.println("</tr>");
		
		out.println("<tr>");
		out.println("<td>EmailId</td>");
		out.println("<td><input type='text' name='emailId'></td>");
		out.println("</tr>");
		
		
		out.println("<tr>");
		out.println("<td><input type='submit' name='Submit'></td>");
		out.println("</tr>");
		
		out.println("</table>");
		out.println("</form>");
		out.println("</body>");
		out.println("</html>");
	}

}
