package com.cg.views;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/FinalServlet")
public class FinalServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
    public FinalServlet() {
        super();
        
    }
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		String firstName=null,state=null,city=null,lastName=null;
		String emailId=request.getParameter("emailId");
		String mobileNo=request.getParameter("mobileNo");
		Cookie[] cookies=request.getCookies();
		for (Cookie cookie : cookies) {
			if(cookie.getName().equals("firstName"))
				firstName=cookie.getValue();
			else if(cookie.getName().equals("lastName"))
				lastName=cookie.getValue();
			else if(cookie.getName().equals("city"))
				city=cookie.getValue();
			else if(cookie.getName().equals("state"))
				state=cookie.getValue();	
		}
		
		out.println("<html>");
		out.println("<head>");
		out.println("</head>");
		out.println("<body>");
		
		out.println("<table>");
		out.println("<tr>");
		out.println("<td>FirstName</td>");
		out.println("<td>"+firstName+"</td>");
		out.println("</tr>");
		
		out.println("<tr>");
		out.println("<td>LastName</td>");
		out.println("<td>"+lastName+"</td>");
		out.println("</tr>");
		
		out.println("<tr>");
		out.println("<td>City</td>");
		out.println("<td>"+city+"</td>");
		out.println("</tr>");
		
		out.println("<tr>");
		out.println("<td>State</td>");
		out.println("<td>"+state+"</td>");
		out.println("</tr>");		
					
		out.println("<tr>");
		out.println("<td>MobileNo</td>");
		out.println("<td>"+mobileNo+"</td>");
		out.println("</tr>");	
		
		out.println("<tr>");
		out.println("<td>EmailId</td>");
		out.println("<td>"+emailId+"</td>");
		out.println("</tr>");	
		
		out.println("</table>");
		out.println("</form>");
		out.println("</body>");
		out.println("</html>");
	}

}
