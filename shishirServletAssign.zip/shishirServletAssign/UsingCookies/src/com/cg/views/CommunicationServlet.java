package com.cg.views;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/CommunicationServlet")
public class CommunicationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public CommunicationServlet() {
        super();
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		String firstName=null,lastName=null;
		Cookie[] cookies=request.getCookies();
		for (Cookie cookie : cookies) {
			if(cookie.getName().equals("firstName"))
				firstName=cookie.getValue();
			else if(cookie.getName().equals("lastName"))
				lastName=cookie.getValue();
		}
		String city=request.getParameter("city");
		String state=request.getParameter("state");
		
		Cookie c1=new Cookie("firstName", firstName);
		Cookie c2=new Cookie("lastName", lastName);
		Cookie c3=new Cookie("city", city);
		Cookie c4=new Cookie("state", state);
		response.addCookie(c1);
		response.addCookie(c2);
		response.addCookie(c3);
		response.addCookie(c4);
		
		out.println("<html>");
		out.println("<head>");
		out.println("</head>");
		out.println("<body>");
		
		out.println("<table>");
		out.println("<tr>");
		out.println("<td>FirstName</td>");
		out.println("<td>"+firstName+"</td>");
		out.println("</tr>");
		
		out.println("<tr>");
		out.println("<td>LastName</td>");
		out.println("<td>"+lastName+"</td>");
		out.println("</tr>");
		
		out.println("<tr>");
		out.println("<td>City</td>");
		out.println("<td>"+city+"</td>");
		out.println("</tr>");
		
		out.println("<tr>");
		out.println("<td>State</td>");
		out.println("<td>"+state+"</td>");
		out.println("</tr>");		
		out.println("</table>");
		
		
		out.println("<form name='Addressform' action='FinalServlet' method='post'>");
		out.println("<table>");
		
		
		out.println("<tr>");
		out.println("<td>MobileNo</td>");
		out.println("<td><input type='text' name='mobileNo'></td>");
		out.println("</tr>");
		
		out.println("<tr>");
		out.println("<td>EmailId</td>");
		out.println("<td><input type='text' name='emailId'></td>");
		out.println("</tr>");
		
		
		out.println("<tr>");
		out.println("<td><input type='submit' name='Submit'></td>");
		out.println("</tr>");
		
		out.println("</table>");
		out.println("</form>");
		out.println("</body>");
		out.println("</html>");
	}

}
