package com.cg.bean;

public class user {
	String firstName,lastName,city,state,mobileNo,emailId; 

}
