package com.cg.views;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.bean.UserBean;


@WebServlet("/FinalServlet")
public class FinalServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	ServletContext servletContext;
   
    public FinalServlet() {
        super();      
    }
    

    public void init(){   	
 	servletContext=getServletContext();
    }
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		UserBean user=(UserBean) servletContext.getAttribute("UserBean");
		user.setEmailId(request.getParameter("emailId"));
		user.setMobileNo(request.getParameter("mobileNo"));
		servletContext.setAttribute("UserBean", user);
		out.println("<html>");
		out.println("<head>");
		out.println("</head>");
		out.println("<body>");
		
		out.println("<table>");
		out.println("<tr>");
		out.println("<td>FirstName</td>");
		out.println("<td>"+user.getFirstName()+"</td>");
		out.println("</tr>");
		
		out.println("<tr>");
		out.println("<td>LastName</td>");
		out.println("<td>"+user.getLastName()+"</td>");
		out.println("</tr>");
		
		out.println("<tr>");
		out.println("<td>City</td>");
		out.println("<td>"+user.getCity()+"</td>");
		out.println("</tr>");
		
		out.println("<tr>");
		out.println("<td>State</td>");
		out.println("<td>"+user.getState()+"</td>");
		out.println("</tr>");		
					
		out.println("<tr>");
		out.println("<td>MobileNo</td>");
		out.println("<td>"+user.getMobileNo()+"</td>");
		out.println("</tr>");	
		
		out.println("<tr>");
		out.println("<td>EmailId</td>");
		out.println("<td>"+user.getEmailId()+"</td>");
		out.println("</tr>");	
		
		out.println("</table>");
		out.println("</form>");
		out.println("</body>");
		out.println("</html>");
	}

}
